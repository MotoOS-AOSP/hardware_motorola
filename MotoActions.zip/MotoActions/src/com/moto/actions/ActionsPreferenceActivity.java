/*
 * Copyright (c) 2016 The CyanogenMod Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.moto.actions;

import android.os.Bundle;
import android.widget.Toolbar;
import com.android.settingslib.collapsingtoolbar.CollapsingToolbarBaseActivity;

public class ActionsPreferenceActivity extends CollapsingToolbarBaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actions_preference);

        Toolbar toolbar = findViewById(R.id.toolbar);
        if (toolbar != null) {
            toolbar.setTitle(R.string.moto_actions_title); // Configura el título del Toolbar
            setActionBar(toolbar); // Configura el Toolbar como la ActionBar
        }

        if (savedInstanceState == null) {
            getFragmentManager().beginTransaction()
                .replace(R.id.content_frame, new ActionsPreferenceFragment()).commit();
        }
    }
}

